package images;

//interface for TwoDFunc
public interface TwoDFunc {
	public double f(double x, double y);
}
