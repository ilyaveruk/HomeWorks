package iterator;

public interface MyIterator {
	//interface for MyIterator
	boolean hasNext();
	int next();
}
